console.log('我是a模块')
// CommonJS的导出语法规范
// module.exports = {
//   name: 'aaa'
// }

// ES6的导出语法规范
export default {
  name: 'aaa'
}