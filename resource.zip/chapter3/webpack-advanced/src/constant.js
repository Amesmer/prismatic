export let a = 10
export let b = 20
export let c = 30