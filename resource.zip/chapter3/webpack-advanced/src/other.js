console.log('我是other.js')

// import $ from 'jquery'

// $('body img').css('width', '300px').css('height', '300px')