module.exports = {
  content: '今天要下雨了!!!'
}