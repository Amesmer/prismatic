let message = require('./message.js')

module.exports = {
  content: '今天有个大新闻,爆炸消息!!!内容是:' + message.content
}