let news = require('./news.js')
console.log(news.content)

// require('./index.css')