const sum = (a: number, b: number) => a + b;

export default sum;
