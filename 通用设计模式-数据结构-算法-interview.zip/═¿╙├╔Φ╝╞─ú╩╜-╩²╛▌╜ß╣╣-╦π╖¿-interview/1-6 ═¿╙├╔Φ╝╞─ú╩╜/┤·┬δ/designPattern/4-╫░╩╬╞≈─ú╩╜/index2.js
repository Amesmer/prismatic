function log(target,name,descriptor) {
  // target此时是Math.prototype
  //name 此时是方法名 也就是'add'
  //descriptor
/*  {
    value:函数
    enumerable:是否可遍历
    configurable:是否可配置
    writable:是否可以重写
  }*/
let oldFn = descriptor.value
  descriptor.value = function () {
    console.log(`正在调用${name}方法，参数：`,arguments);
    return oldFn.apply(this,arguments)
  }
}




class Math {
  @log
  add(a,b){
    return a + b
  }
}

window.math = new Math()