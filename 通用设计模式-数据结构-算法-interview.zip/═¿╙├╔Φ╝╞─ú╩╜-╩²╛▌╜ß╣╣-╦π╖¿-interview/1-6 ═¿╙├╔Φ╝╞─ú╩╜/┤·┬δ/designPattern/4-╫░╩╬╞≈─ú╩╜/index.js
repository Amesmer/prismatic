function code(target) {
  target.prototype.code = function () {
    console.log('写代码');
  }
}

@code
class Phone {
  makeCall() {
    console.log('打电话');
  }
}

window.phone = new Phone()