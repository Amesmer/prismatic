import {readonly, autobind,deprecate} from 'core-decorators'

class Phone {
  @deprecate
  makeCall() {
    console.log('打电话');
  }
}

window.phone = new Phone()
